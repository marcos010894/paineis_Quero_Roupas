<?php include'menu.php' ?>
<div class="content-wrapper"> 
    <div class="container">
    <div id="avalia" class="row">

    </div>      
</div>
</div>
</div>
<?php include'footer.php' ?>
<script src="dist/js/avaliation.js"></script>
