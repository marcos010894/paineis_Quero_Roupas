<?php 
session_start();
if(isset($_SESSION['usuario'])){
	?>
<?php include'menu.php' ?>
<div class="content-wrapper"> 
  <div class="container">
  <div class="container">
  <div class="row" id="pedidos">
   
  </div>
 </div>
      
  </div>
</div>
<?php include'footer.php' ?>
<script src="dist/js/pedidosconcluidos.js"></script>
<?php 
}else{
	header("location:login.php");
}
?>