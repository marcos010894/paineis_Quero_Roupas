<?php include'menu.php' ?>
<div class="content-wrapper"> 
  <div class="container">
  <div class="container">
    <table>
      <tr>  
        <div class="row" id="pedidos"></div>
      </tr>
    </table>

</div>
      
  </div>
</div>
<?php include'footer.php' ?>
<script src="dist/js/pedidoandamento.js"></script>
