
<?php include 'menu.php' ?>
<style>
  .grapchsDay{
    width:100%;
    height:150px;
    background-color: #5AF27C;
    padding: 10%;
    border-radius:20px;
    box-shadow: 5px 10px #eeeeee;
    color:white;
    font-size:25px;
    text-align:center;
  }
  .grapchsMes{
    width:100%;
    height:150px;
    background-color: #5C82DB;
    padding:10%;
    border-radius:20px;
    box-shadow: 5px #eeeeee  ;
    color:white;
    font-size:25px;
    text-align:center;
  }
  .grapchsYer{
    width:100%;
    height:150px;
    background-color: #EB8C04;
    padding:10%;
    border-radius:20px;
    box-shadow: 5px 10px #e4e4e4   ;
    color:white;
    font-size:25px;
    text-align:center;
  }
  .valorgrap{
    font-size:35px;
  }
</style>
    <!-- Main content --><br>
    <section class="content-wrapper">
      <div class="container"> 
        <div class="row"> 
            <DIV class="col-md">
              <div class="grapchsDay">
                Vendido Hoje.
                <div class="valorgrap">R$ 450</div>
              </div>
              
            </DIV>
            <DIV class="col-md">
            <div class="grapchsMes">Vendido esse mês.
              <div class="valorgrap">R$ 450</div>
            </div>
            </DIV>
            <DIV class="col-md">
            <div class="grapchsYer">Vendido esse ano.
              <div class="valorgrap">R$ 450</div>
            </div>
            </DIV>
          </div><br><br>

          <div id="chart"></div>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', { packages: [ 'corechart' ] })
        google.charts.setOnLoadCallback(drawChart)

        function drawChart() {
            const container = document.querySelector('#chart')
            const data = new google.visualization.arrayToDataTable([
                [ 'Character', 'Valor' ],
                [ 'Jan', 2000 ],
                [ 'Fev', 2500 ],
                [ 'Mar', 3000 ],
                [ 'Abr', 5000 ],
                [ 'Maio', 1000 ],
                [ 'Jun', 1500 ],
                [ 'Jul', 560 ],
                [ 'Agot', 1000 ],
                [ 'Set', 5000 ],
                [ 'Out', 3500 ],
                [ 'Nov', 5000 ],
                [ 'Dez', 7000 ],
            ])
            const options = {
                title: 'Vendas No ano',
                height: 400,
                width: 1000
            }

            // const chart = new google.visualization.ColumnChart(container)
            // const chart = new google.visualization.BarChart(container)
            // const chart = new google.visualization.LineChart(container)
            const chart = new google.visualization.LineChart(container)
            chart.draw(data, options)
        }
    </script>
      </div> 
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<?php include 'footer.php' ?>